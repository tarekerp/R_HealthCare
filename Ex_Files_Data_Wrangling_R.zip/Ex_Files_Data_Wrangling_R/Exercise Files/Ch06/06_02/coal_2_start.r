# Data Wrangling in R
# Coal Consumption Case Study

